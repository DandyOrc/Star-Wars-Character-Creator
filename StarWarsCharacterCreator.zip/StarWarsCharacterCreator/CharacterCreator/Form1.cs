﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CharacterCreator
{
    public partial class frmMain : Form
    {
        int CharaterPoints = 25;
        int StrengthPoints = 0;
        int AgilityPoints = 0;
        int AttackPoints = 0;
		int DefencePoints = 0;
		int VitalityPoints = 0;
		int CharismaPoints = 0;
		int StaminaPoints = 0;
		int ForcePoints = 0;

        int Gender;

        int CurrentPicture;

        Image[] PictureFemales = new Image[9];
        Image[] PictureMales = new Image[9];

        public frmMain()
        {
            InitializeComponent();
            SetImageArray();
            UpdateValues();
        }
        private void SetImageArray()
        {
            PictureFemales[0] = Image.FromFile(@"..\..\Images\F_Character01.jpg");
            PictureFemales[1] = Image.FromFile(@"..\..\Images\F_Character02.jpg");
            PictureFemales[2] = Image.FromFile(@"..\..\Images\F_Character03.jpg");
            PictureFemales[3] = Image.FromFile(@"..\..\Images\F_Character04.jpg");
            PictureFemales[4] = Image.FromFile(@"..\..\Images\F_Character05.jpg");
            PictureFemales[5] = Image.FromFile(@"..\..\Images\F_Character06.jpg");
            PictureFemales[6] = Image.FromFile(@"..\..\Images\F_Character07.jpg");
            PictureFemales[7] = Image.FromFile(@"..\..\Images\F_Character08.jpg");
            PictureFemales[8] = Image.FromFile(@"..\..\Images\F_Character09.jpg");
            PictureMales[0] = Image.FromFile(@"..\..\Images\M_Character01.jpg");
            PictureMales[1] = Image.FromFile(@"..\..\Images\M_Character02.jpg");
            PictureMales[2] = Image.FromFile(@"..\..\Images\M_Character03.jpg");
            PictureMales[3] = Image.FromFile(@"..\..\Images\M_Character04.jpg");
            PictureMales[4] = Image.FromFile(@"..\..\Images\M_Character05.jpg");
            PictureMales[5] = Image.FromFile(@"..\..\Images\M_Character06.jpg");
            PictureMales[6] = Image.FromFile(@"..\..\Images\M_Character07.jpg");
            PictureMales[7] = Image.FromFile(@"..\..\Images\M_Character08.jpg");
            PictureMales[8] = Image.FromFile(@"..\..\Images\M_Character09.jpg");
        }

        private void btnStrengthDown_Click(object sender, EventArgs e)
        {
            if (StrengthPoints > 0)
            {
                StrengthPoints--;
                CharaterPoints++;
                UpdateValues();
            }
        }

        private void btnStrengthUp_Click(object sender, EventArgs e)
        {
            if (CharaterPoints > 0)
            {
                StrengthPoints++;
                CharaterPoints--;
                UpdateValues();
            }
        }

        private void btnAgilityUp_Click(object sender, EventArgs e)
        {
            if (CharaterPoints > 0)
            {
                AgilityPoints++;
                CharaterPoints--;
                UpdateValues();
            }
        }

        private void btnAgilityDown_Click(object sender, EventArgs e)
        {
            if (AgilityPoints > 0)
            {
                AgilityPoints--;
                CharaterPoints++;
                UpdateValues();
            }
        }

        private void btnAttackDown_Click(object sender, EventArgs e)
        {
            if (AttackPoints > 0)
            {
                AttackPoints--;
                CharaterPoints++;
                UpdateValues();
            }
        }

        private void btnAttackUp_Click(object sender, EventArgs e)
        {
            if (CharaterPoints > 0)
            {
                AttackPoints++;
                CharaterPoints--;
                UpdateValues();
            }
        }
	private void btnDefenceDown_Click(object sender, EventArgs e)
		{
			if (DefencePoints > 0)
			{
				DefencePoints--;
				CharaterPoints++;
				UpdateValues();
			}
		}

		private void btnDefenceUp_Click(object sender, EventArgs e)
		{
			if (CharaterPoints > 0)
			{
				DefencePoints++;
				CharaterPoints--;
				UpdateValues();
			}
		}

		private void btnVitalityDown_Click(object sender, EventArgs e)
		{
			if (VitalityPoints > 0)
			{
				VitalityPoints--;
				CharaterPoints++;
				UpdateValues();
			}
		}

		private void btnVitalityUp_Click(object sender, EventArgs e)
		{
			if (CharaterPoints > 0)
			{
				VitalityPoints++;
				CharaterPoints--;
				UpdateValues();
			}
		}

		private void btnCharismaDown_Click(object sender, EventArgs e)
		{
			if (CharismaPoints > 0)
			{
				CharismaPoints--;
				CharaterPoints++;
				UpdateValues();
			}
		}

		private void btnCharismaUp_Click(object sender, EventArgs e)
		{
			if (CharaterPoints > 0)
			{
				CharismaPoints++;
				CharaterPoints--;
				UpdateValues();
			}
		}

		private void btnStaminaDown_Click(object sender, EventArgs e)
		{
			if (StaminaPoints > 0)
			{
				StaminaPoints--;
				CharaterPoints++;
				UpdateValues();
			}
		}

		private void btnStaminaUp_Click(object sender, EventArgs e)
		{
			if (CharaterPoints > 0)
			{
				StaminaPoints++;
				CharaterPoints--;
				UpdateValues();
			}
		}

		private void btnForceDown_Click(object sender, EventArgs e)
		{
			if (ForcePoints > 0)
			{
				ForcePoints--;
				CharaterPoints++;
				UpdateValues();
			}
		}

		private void btnForceUp_Click(object sender, EventArgs e)
		{
			if (CharaterPoints > 0)
			{
				ForcePoints++;
				CharaterPoints--;
				UpdateValues();
			}
		}

        private void UpdateValues()
        {
            lblStrength.Text = "Strength: " + StrengthPoints.ToString();
            lblAgility.Text = "Agility: " + AgilityPoints.ToString();
            lblAttack.Text = "Attack: " + AttackPoints.ToString();
			lblDefence.Text = "Defence: " + DefencePoints.ToString();
			lblVitality.Text = "Vitality: " + VitalityPoints.ToString();
			lblCharisma.Text = "Charisma: " + CharismaPoints.ToString();
			lblStamina.Text = "Stamina: " + StaminaPoints.ToString();
			lblForce.Text = "Force: " + ForcePoints.ToString();
            lblCharacterPoints.Text = "Skill Points: " + CharaterPoints.ToString();
            if (Gender == 0)
            {
                rdoBtnFemale.Checked = true;
                rdoBtnMale.Checked = false;
                picBoxPortraits.Image = PictureFemales[CurrentPicture];
            }
            else if (Gender == 1)
            {
                rdoBtnFemale.Checked = false;
                rdoBtnMale.Checked = true;
                picBoxPortraits.Image = PictureMales[CurrentPicture];

            }
        }
        
        private void UpdatePictureBox()
        {
            if (Gender == 0)
            {
                picBoxPortraits.Image = PictureFemales[CurrentPicture];
            }
            else if (Gender == 1)
            {
                picBoxPortraits.Image = PictureMales[CurrentPicture];
            }
        }

        private void btnSaveFile_Click(object sender, EventArgs e)
        {
            sfdSave.ShowDialog();
            if (sfdSave.FileName != null)
            {
                StreamWriter sw = new StreamWriter(sfdSave.FileName);
                sw.WriteLine(CharaterPoints);
                sw.WriteLine(AgilityPoints);
                sw.WriteLine(AttackPoints);
                sw.WriteLine(StrengthPoints);
                sw.WriteLine(DefencePoints);
                sw.WriteLine(VitalityPoints);
                sw.WriteLine(CharismaPoints);
                sw.WriteLine(StaminaPoints);
                sw.WriteLine(ForcePoints);
                sw.WriteLine(txtBoxName.Text);
                sw.WriteLine(Gender);
                sw.Close();
            }
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            ofdOpen.ShowDialog();
            
            if (ofdOpen.FileName != null)
            {
                StreamReader sr = new StreamReader(ofdOpen.FileName);
                CharaterPoints = Convert.ToInt32(sr.ReadLine());
                AgilityPoints = Convert.ToInt32(sr.ReadLine());
                AttackPoints = Convert.ToInt32(sr.ReadLine());
                StrengthPoints = Convert.ToInt32(sr.ReadLine());
                DefencePoints = Convert.ToInt32(sr.ReadLine());
                VitalityPoints = Convert.ToInt32(sr.ReadLine());
                CharismaPoints = Convert.ToInt32(sr.ReadLine());
                StaminaPoints = Convert.ToInt32(sr.ReadLine());
                ForcePoints = Convert.ToInt32(sr.ReadLine());
                txtBoxName.Text = sr.ReadLine();
                Gender = Convert.ToInt32(sr.ReadLine());
                sr.Close();
                UpdateValues();

            }
        }

        private void rdoBtnFemale_CheckedChanged(object sender, EventArgs e)
        {
            Gender = 0;
            UpdatePictureBox();
        }

        private void rdoBtnMale_CheckedChanged(object sender, EventArgs e)
        {
            Gender = 1;
            UpdatePictureBox();
        }

        private void btnPictureNext_Click(object sender, EventArgs e)
        {
            if (rdoBtnFemale.Checked)
            {
                if (CurrentPicture >= PictureFemales.Length - 1)
                {
                    CurrentPicture = 0;
                }
                else
                {
                    CurrentPicture++;
                }
            }
            else if (rdoBtnMale.Checked)
            {
                if (CurrentPicture >= PictureMales.Length - 1)
                {
                    CurrentPicture = 0;
                }
                else
                {
                    CurrentPicture++;
                }
            }
            UpdateValues();

        }

        private void btnPicturePrev_Click(object sender, EventArgs e)
        {
            if (rdoBtnFemale.Checked)
            {
                if (CurrentPicture <= 0)
                {
                    CurrentPicture = PictureFemales.Length - 1;
                }
                else
                {
                    CurrentPicture--;
                }
            }
            else if (rdoBtnMale.Checked)
            {
                if (CurrentPicture <= 0)
                {
                    CurrentPicture = PictureMales.Length - 1;
                }
                else
                {
                    CurrentPicture--;
                }
            }
            UpdateValues();
        }
    }
}
