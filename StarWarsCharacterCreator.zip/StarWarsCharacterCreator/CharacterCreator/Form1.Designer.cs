﻿namespace CharacterCreator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.lblName = new System.Windows.Forms.Label();
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.grpBoxGender = new System.Windows.Forms.GroupBox();
            this.rdoBtnFemale = new System.Windows.Forms.RadioButton();
            this.rdoBtnMale = new System.Windows.Forms.RadioButton();
            this.btnStrengthDown = new System.Windows.Forms.Button();
            this.btnStrengthUp = new System.Windows.Forms.Button();
            this.btnAgilityDown = new System.Windows.Forms.Button();
            this.btnAgilityUp = new System.Windows.Forms.Button();
            this.btnAttackDown = new System.Windows.Forms.Button();
            this.btnAttackUp = new System.Windows.Forms.Button();
            this.lblCharacterPoints = new System.Windows.Forms.Label();
            this.lblStrength = new System.Windows.Forms.Label();
            this.lblAgility = new System.Windows.Forms.Label();
            this.lblAttack = new System.Windows.Forms.Label();
            this.btnSaveFile = new System.Windows.Forms.Button();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.sfdSave = new System.Windows.Forms.SaveFileDialog();
            this.ofdOpen = new System.Windows.Forms.OpenFileDialog();
            this.picBoxPortraits = new System.Windows.Forms.PictureBox();
            this.btnPicturePrev = new System.Windows.Forms.Button();
            this.btnPictureNext = new System.Windows.Forms.Button();
            this.btnCharismaDown = new System.Windows.Forms.Button();
            this.btnStaminaDown = new System.Windows.Forms.Button();
            this.btnForceDown = new System.Windows.Forms.Button();
            this.btnDefenceDown = new System.Windows.Forms.Button();
            this.btnVitalityDown = new System.Windows.Forms.Button();
            this.lblForce = new System.Windows.Forms.Label();
            this.lblStamina = new System.Windows.Forms.Label();
            this.lblCharisma = new System.Windows.Forms.Label();
            this.lblVitality = new System.Windows.Forms.Label();
            this.lblDefence = new System.Windows.Forms.Label();
            this.btnVitalityUp = new System.Windows.Forms.Button();
            this.btnCharismaUp = new System.Windows.Forms.Button();
            this.btnStaminaUp = new System.Windows.Forms.Button();
            this.btnForceUp = new System.Windows.Forms.Button();
            this.btnDefenceUp = new System.Windows.Forms.Button();
            this.grpBoxSkillPoints = new System.Windows.Forms.GroupBox();
            this.grpBoxSkills = new System.Windows.Forms.GroupBox();
            this.lblStarWarsCharacterCreator = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.grpBoxGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPortraits)).BeginInit();
            this.grpBoxSkillPoints.SuspendLayout();
            this.grpBoxSkills.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Star Jedi Logo DoubleLine1", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(40, 136);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(164, 19);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Enter name below";
            // 
            // txtBoxName
            // 
            this.txtBoxName.Location = new System.Drawing.Point(43, 157);
            this.txtBoxName.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(232, 22);
            this.txtBoxName.TabIndex = 1;
            // 
            // grpBoxGender
            // 
            this.grpBoxGender.Controls.Add(this.rdoBtnFemale);
            this.grpBoxGender.Controls.Add(this.rdoBtnMale);
            this.grpBoxGender.Font = new System.Drawing.Font("Star Jedi Logo DoubleLine1", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxGender.Location = new System.Drawing.Point(43, 205);
            this.grpBoxGender.Margin = new System.Windows.Forms.Padding(4);
            this.grpBoxGender.Name = "grpBoxGender";
            this.grpBoxGender.Padding = new System.Windows.Forms.Padding(4);
            this.grpBoxGender.Size = new System.Drawing.Size(232, 196);
            this.grpBoxGender.TabIndex = 2;
            this.grpBoxGender.TabStop = false;
            this.grpBoxGender.Text = "Gender";
            // 
            // rdoBtnFemale
            // 
            this.rdoBtnFemale.AutoSize = true;
            this.rdoBtnFemale.Location = new System.Drawing.Point(77, 114);
            this.rdoBtnFemale.Margin = new System.Windows.Forms.Padding(4);
            this.rdoBtnFemale.Name = "rdoBtnFemale";
            this.rdoBtnFemale.Size = new System.Drawing.Size(88, 23);
            this.rdoBtnFemale.TabIndex = 1;
            this.rdoBtnFemale.TabStop = true;
            this.rdoBtnFemale.Text = "Female";
            this.rdoBtnFemale.UseVisualStyleBackColor = true;
            this.rdoBtnFemale.CheckedChanged += new System.EventHandler(this.rdoBtnFemale_CheckedChanged);
            // 
            // rdoBtnMale
            // 
            this.rdoBtnMale.AutoSize = true;
            this.rdoBtnMale.Location = new System.Drawing.Point(77, 62);
            this.rdoBtnMale.Margin = new System.Windows.Forms.Padding(4);
            this.rdoBtnMale.Name = "rdoBtnMale";
            this.rdoBtnMale.Size = new System.Drawing.Size(70, 23);
            this.rdoBtnMale.TabIndex = 0;
            this.rdoBtnMale.TabStop = true;
            this.rdoBtnMale.Text = "Male";
            this.rdoBtnMale.UseVisualStyleBackColor = true;
            this.rdoBtnMale.CheckedChanged += new System.EventHandler(this.rdoBtnMale_CheckedChanged);
            // 
            // btnStrengthDown
            // 
            this.btnStrengthDown.Location = new System.Drawing.Point(18, 27);
            this.btnStrengthDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStrengthDown.Name = "btnStrengthDown";
            this.btnStrengthDown.Size = new System.Drawing.Size(75, 23);
            this.btnStrengthDown.TabIndex = 3;
            this.btnStrengthDown.Text = "-";
            this.btnStrengthDown.UseVisualStyleBackColor = true;
            this.btnStrengthDown.Click += new System.EventHandler(this.btnStrengthDown_Click);
            // 
            // btnStrengthUp
            // 
            this.btnStrengthUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStrengthUp.Location = new System.Drawing.Point(217, 30);
            this.btnStrengthUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStrengthUp.Name = "btnStrengthUp";
            this.btnStrengthUp.Size = new System.Drawing.Size(75, 23);
            this.btnStrengthUp.TabIndex = 4;
            this.btnStrengthUp.Text = "+";
            this.btnStrengthUp.UseVisualStyleBackColor = true;
            this.btnStrengthUp.Click += new System.EventHandler(this.btnStrengthUp_Click);
            // 
            // btnAgilityDown
            // 
            this.btnAgilityDown.Location = new System.Drawing.Point(18, 67);
            this.btnAgilityDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAgilityDown.Name = "btnAgilityDown";
            this.btnAgilityDown.Size = new System.Drawing.Size(75, 23);
            this.btnAgilityDown.TabIndex = 5;
            this.btnAgilityDown.Text = "-";
            this.btnAgilityDown.UseVisualStyleBackColor = true;
            this.btnAgilityDown.Click += new System.EventHandler(this.btnAgilityDown_Click);
            // 
            // btnAgilityUp
            // 
            this.btnAgilityUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgilityUp.Location = new System.Drawing.Point(217, 67);
            this.btnAgilityUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAgilityUp.Name = "btnAgilityUp";
            this.btnAgilityUp.Size = new System.Drawing.Size(75, 23);
            this.btnAgilityUp.TabIndex = 6;
            this.btnAgilityUp.Text = "+";
            this.btnAgilityUp.UseVisualStyleBackColor = true;
            this.btnAgilityUp.Click += new System.EventHandler(this.btnAgilityUp_Click);
            // 
            // btnAttackDown
            // 
            this.btnAttackDown.Location = new System.Drawing.Point(16, 107);
            this.btnAttackDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAttackDown.Name = "btnAttackDown";
            this.btnAttackDown.Size = new System.Drawing.Size(75, 23);
            this.btnAttackDown.TabIndex = 7;
            this.btnAttackDown.Text = "-";
            this.btnAttackDown.UseVisualStyleBackColor = true;
            this.btnAttackDown.Click += new System.EventHandler(this.btnAttackDown_Click);
            // 
            // btnAttackUp
            // 
            this.btnAttackUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttackUp.Location = new System.Drawing.Point(217, 107);
            this.btnAttackUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAttackUp.Name = "btnAttackUp";
            this.btnAttackUp.Size = new System.Drawing.Size(75, 23);
            this.btnAttackUp.TabIndex = 8;
            this.btnAttackUp.Text = "+";
            this.btnAttackUp.UseVisualStyleBackColor = true;
            this.btnAttackUp.Click += new System.EventHandler(this.btnAttackUp_Click);
            // 
            // lblCharacterPoints
            // 
            this.lblCharacterPoints.AutoSize = true;
            this.lblCharacterPoints.Location = new System.Drawing.Point(6, 36);
            this.lblCharacterPoints.Name = "lblCharacterPoints";
            this.lblCharacterPoints.Size = new System.Drawing.Size(108, 23);
            this.lblCharacterPoints.TabIndex = 9;
            this.lblCharacterPoints.Text = "Skill Points";
            // 
            // lblStrength
            // 
            this.lblStrength.AutoSize = true;
            this.lblStrength.Location = new System.Drawing.Point(110, 30);
            this.lblStrength.Name = "lblStrength";
            this.lblStrength.Size = new System.Drawing.Size(86, 23);
            this.lblStrength.TabIndex = 10;
            this.lblStrength.Text = "Strength";
            // 
            // lblAgility
            // 
            this.lblAgility.AutoSize = true;
            this.lblAgility.Location = new System.Drawing.Point(110, 67);
            this.lblAgility.Name = "lblAgility";
            this.lblAgility.Size = new System.Drawing.Size(66, 23);
            this.lblAgility.TabIndex = 11;
            this.lblAgility.Text = "Agility";
            // 
            // lblAttack
            // 
            this.lblAttack.AutoSize = true;
            this.lblAttack.Location = new System.Drawing.Point(110, 110);
            this.lblAttack.Name = "lblAttack";
            this.lblAttack.Size = new System.Drawing.Size(68, 23);
            this.lblAttack.TabIndex = 12;
            this.lblAttack.Text = "Attack";
            // 
            // btnSaveFile
            // 
            this.btnSaveFile.Font = new System.Drawing.Font("Star Jedi Rounded", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveFile.Location = new System.Drawing.Point(943, 469);
            this.btnSaveFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSaveFile.Name = "btnSaveFile";
            this.btnSaveFile.Size = new System.Drawing.Size(116, 33);
            this.btnSaveFile.TabIndex = 13;
            this.btnSaveFile.Text = "Save file";
            this.btnSaveFile.UseVisualStyleBackColor = true;
            this.btnSaveFile.Click += new System.EventHandler(this.btnSaveFile_Click);
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenFile.Location = new System.Drawing.Point(793, 470);
            this.btnOpenFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(116, 33);
            this.btnOpenFile.TabIndex = 14;
            this.btnOpenFile.Text = "Open File";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // ofdOpen
            // 
            this.ofdOpen.FileName = "openFileDialog1";
            // 
            // picBoxPortraits
            // 
            this.picBoxPortraits.Image = ((System.Drawing.Image)(resources.GetObject("picBoxPortraits.Image")));
            this.picBoxPortraits.Location = new System.Drawing.Point(816, 157);
            this.picBoxPortraits.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxPortraits.Name = "picBoxPortraits";
            this.picBoxPortraits.Size = new System.Drawing.Size(220, 220);
            this.picBoxPortraits.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxPortraits.TabIndex = 16;
            this.picBoxPortraits.TabStop = false;
            // 
            // btnPicturePrev
            // 
            this.btnPicturePrev.Font = new System.Drawing.Font("Star Jedi Rounded", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPicturePrev.Location = new System.Drawing.Point(816, 391);
            this.btnPicturePrev.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPicturePrev.Name = "btnPicturePrev";
            this.btnPicturePrev.Size = new System.Drawing.Size(93, 30);
            this.btnPicturePrev.TabIndex = 17;
            this.btnPicturePrev.Text = "Previous";
            this.btnPicturePrev.UseVisualStyleBackColor = true;
            this.btnPicturePrev.Click += new System.EventHandler(this.btnPicturePrev_Click);
            // 
            // btnPictureNext
            // 
            this.btnPictureNext.Font = new System.Drawing.Font("Star Jedi Rounded", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPictureNext.Location = new System.Drawing.Point(943, 391);
            this.btnPictureNext.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPictureNext.Name = "btnPictureNext";
            this.btnPictureNext.Size = new System.Drawing.Size(93, 30);
            this.btnPictureNext.TabIndex = 18;
            this.btnPictureNext.Text = "Next";
            this.btnPictureNext.UseVisualStyleBackColor = true;
            this.btnPictureNext.Click += new System.EventHandler(this.btnPictureNext_Click);
            // 
            // btnCharismaDown
            // 
            this.btnCharismaDown.Location = new System.Drawing.Point(18, 227);
            this.btnCharismaDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCharismaDown.Name = "btnCharismaDown";
            this.btnCharismaDown.Size = new System.Drawing.Size(75, 23);
            this.btnCharismaDown.TabIndex = 20;
            this.btnCharismaDown.Text = "-";
            this.btnCharismaDown.UseVisualStyleBackColor = true;
            this.btnCharismaDown.Click += new System.EventHandler(this.btnCharismaDown_Click);
            // 
            // btnStaminaDown
            // 
            this.btnStaminaDown.Location = new System.Drawing.Point(18, 267);
            this.btnStaminaDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStaminaDown.Name = "btnStaminaDown";
            this.btnStaminaDown.Size = new System.Drawing.Size(75, 23);
            this.btnStaminaDown.TabIndex = 21;
            this.btnStaminaDown.Text = "-";
            this.btnStaminaDown.UseVisualStyleBackColor = true;
            this.btnStaminaDown.Click += new System.EventHandler(this.btnStaminaDown_Click);
            // 
            // btnForceDown
            // 
            this.btnForceDown.Location = new System.Drawing.Point(18, 307);
            this.btnForceDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnForceDown.Name = "btnForceDown";
            this.btnForceDown.Size = new System.Drawing.Size(75, 23);
            this.btnForceDown.TabIndex = 22;
            this.btnForceDown.Text = "-";
            this.btnForceDown.UseVisualStyleBackColor = true;
            this.btnForceDown.Click += new System.EventHandler(this.btnForceDown_Click);
            // 
            // btnDefenceDown
            // 
            this.btnDefenceDown.Location = new System.Drawing.Point(18, 147);
            this.btnDefenceDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDefenceDown.Name = "btnDefenceDown";
            this.btnDefenceDown.Size = new System.Drawing.Size(75, 23);
            this.btnDefenceDown.TabIndex = 23;
            this.btnDefenceDown.Text = "-";
            this.btnDefenceDown.UseVisualStyleBackColor = true;
            this.btnDefenceDown.Click += new System.EventHandler(this.btnDefenceDown_Click);
            // 
            // btnVitalityDown
            // 
            this.btnVitalityDown.Location = new System.Drawing.Point(16, 187);
            this.btnVitalityDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVitalityDown.Name = "btnVitalityDown";
            this.btnVitalityDown.Size = new System.Drawing.Size(75, 23);
            this.btnVitalityDown.TabIndex = 24;
            this.btnVitalityDown.Text = "-";
            this.btnVitalityDown.UseVisualStyleBackColor = true;
            this.btnVitalityDown.Click += new System.EventHandler(this.btnVitalityDown_Click);
            // 
            // lblForce
            // 
            this.lblForce.AutoSize = true;
            this.lblForce.Location = new System.Drawing.Point(110, 310);
            this.lblForce.Name = "lblForce";
            this.lblForce.Size = new System.Drawing.Size(60, 23);
            this.lblForce.TabIndex = 28;
            this.lblForce.Text = "Force";
            // 
            // lblStamina
            // 
            this.lblStamina.AutoSize = true;
            this.lblStamina.Location = new System.Drawing.Point(110, 270);
            this.lblStamina.Name = "lblStamina";
            this.lblStamina.Size = new System.Drawing.Size(72, 23);
            this.lblStamina.TabIndex = 29;
            this.lblStamina.Text = "Stamina";
            // 
            // lblCharisma
            // 
            this.lblCharisma.AutoSize = true;
            this.lblCharisma.Location = new System.Drawing.Point(110, 230);
            this.lblCharisma.Name = "lblCharisma";
            this.lblCharisma.Size = new System.Drawing.Size(84, 23);
            this.lblCharisma.TabIndex = 30;
            this.lblCharisma.Text = "Charisma";
            // 
            // lblVitality
            // 
            this.lblVitality.AutoSize = true;
            this.lblVitality.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVitality.Location = new System.Drawing.Point(110, 194);
            this.lblVitality.Name = "lblVitality";
            this.lblVitality.Size = new System.Drawing.Size(67, 16);
            this.lblVitality.TabIndex = 31;
            this.lblVitality.Text = "Vitality";
            // 
            // lblDefence
            // 
            this.lblDefence.AutoSize = true;
            this.lblDefence.Location = new System.Drawing.Point(110, 150);
            this.lblDefence.Name = "lblDefence";
            this.lblDefence.Size = new System.Drawing.Size(77, 23);
            this.lblDefence.TabIndex = 32;
            this.lblDefence.Text = "Defence";
            // 
            // btnVitalityUp
            // 
            this.btnVitalityUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVitalityUp.Location = new System.Drawing.Point(217, 187);
            this.btnVitalityUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVitalityUp.Name = "btnVitalityUp";
            this.btnVitalityUp.Size = new System.Drawing.Size(75, 23);
            this.btnVitalityUp.TabIndex = 33;
            this.btnVitalityUp.Text = "+";
            this.btnVitalityUp.UseVisualStyleBackColor = true;
            this.btnVitalityUp.Click += new System.EventHandler(this.btnVitalityUp_Click);
            // 
            // btnCharismaUp
            // 
            this.btnCharismaUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCharismaUp.Location = new System.Drawing.Point(217, 227);
            this.btnCharismaUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCharismaUp.Name = "btnCharismaUp";
            this.btnCharismaUp.Size = new System.Drawing.Size(75, 23);
            this.btnCharismaUp.TabIndex = 36;
            this.btnCharismaUp.Text = "+";
            this.btnCharismaUp.UseVisualStyleBackColor = true;
            this.btnCharismaUp.Click += new System.EventHandler(this.btnCharismaUp_Click);
            // 
            // btnStaminaUp
            // 
            this.btnStaminaUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStaminaUp.Location = new System.Drawing.Point(217, 267);
            this.btnStaminaUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStaminaUp.Name = "btnStaminaUp";
            this.btnStaminaUp.Size = new System.Drawing.Size(75, 23);
            this.btnStaminaUp.TabIndex = 37;
            this.btnStaminaUp.Text = "+";
            this.btnStaminaUp.UseVisualStyleBackColor = true;
            this.btnStaminaUp.Click += new System.EventHandler(this.btnStaminaUp_Click);
            // 
            // btnForceUp
            // 
            this.btnForceUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForceUp.Location = new System.Drawing.Point(217, 307);
            this.btnForceUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnForceUp.Name = "btnForceUp";
            this.btnForceUp.Size = new System.Drawing.Size(75, 23);
            this.btnForceUp.TabIndex = 38;
            this.btnForceUp.Text = "+";
            this.btnForceUp.UseVisualStyleBackColor = true;
            this.btnForceUp.Click += new System.EventHandler(this.btnForceUp_Click);
            // 
            // btnDefenceUp
            // 
            this.btnDefenceUp.Font = new System.Drawing.Font("STARWARS", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDefenceUp.Location = new System.Drawing.Point(217, 144);
            this.btnDefenceUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDefenceUp.Name = "btnDefenceUp";
            this.btnDefenceUp.Size = new System.Drawing.Size(75, 23);
            this.btnDefenceUp.TabIndex = 39;
            this.btnDefenceUp.Text = "+";
            this.btnDefenceUp.UseVisualStyleBackColor = true;
            this.btnDefenceUp.Click += new System.EventHandler(this.btnDefenceUp_Click);
            // 
            // grpBoxSkillPoints
            // 
            this.grpBoxSkillPoints.Controls.Add(this.lblCharacterPoints);
            this.grpBoxSkillPoints.Font = new System.Drawing.Font("Star Jedi Rounded", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxSkillPoints.Location = new System.Drawing.Point(640, 145);
            this.grpBoxSkillPoints.Name = "grpBoxSkillPoints";
            this.grpBoxSkillPoints.Size = new System.Drawing.Size(155, 83);
            this.grpBoxSkillPoints.TabIndex = 40;
            this.grpBoxSkillPoints.TabStop = false;
            // 
            // grpBoxSkills
            // 
            this.grpBoxSkills.Controls.Add(this.btnDefenceUp);
            this.grpBoxSkills.Controls.Add(this.btnStrengthDown);
            this.grpBoxSkills.Controls.Add(this.btnStrengthUp);
            this.grpBoxSkills.Controls.Add(this.btnForceUp);
            this.grpBoxSkills.Controls.Add(this.btnAgilityDown);
            this.grpBoxSkills.Controls.Add(this.btnStaminaUp);
            this.grpBoxSkills.Controls.Add(this.btnAgilityUp);
            this.grpBoxSkills.Controls.Add(this.btnCharismaUp);
            this.grpBoxSkills.Controls.Add(this.btnAttackDown);
            this.grpBoxSkills.Controls.Add(this.btnVitalityUp);
            this.grpBoxSkills.Controls.Add(this.btnAttackUp);
            this.grpBoxSkills.Controls.Add(this.lblDefence);
            this.grpBoxSkills.Controls.Add(this.lblStrength);
            this.grpBoxSkills.Controls.Add(this.lblVitality);
            this.grpBoxSkills.Controls.Add(this.lblAgility);
            this.grpBoxSkills.Controls.Add(this.lblCharisma);
            this.grpBoxSkills.Controls.Add(this.lblAttack);
            this.grpBoxSkills.Controls.Add(this.lblStamina);
            this.grpBoxSkills.Controls.Add(this.btnCharismaDown);
            this.grpBoxSkills.Controls.Add(this.lblForce);
            this.grpBoxSkills.Controls.Add(this.btnStaminaDown);
            this.grpBoxSkills.Controls.Add(this.btnVitalityDown);
            this.grpBoxSkills.Controls.Add(this.btnForceDown);
            this.grpBoxSkills.Controls.Add(this.btnDefenceDown);
            this.grpBoxSkills.Font = new System.Drawing.Font("Star Jedi Rounded", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBoxSkills.Location = new System.Drawing.Point(313, 145);
            this.grpBoxSkills.Name = "grpBoxSkills";
            this.grpBoxSkills.Size = new System.Drawing.Size(308, 349);
            this.grpBoxSkills.TabIndex = 41;
            this.grpBoxSkills.TabStop = false;
            this.grpBoxSkills.Text = "Skills";
            // 
            // lblStarWarsCharacterCreator
            // 
            this.lblStarWarsCharacterCreator.AutoSize = true;
            this.lblStarWarsCharacterCreator.Font = new System.Drawing.Font("Star Jedi", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStarWarsCharacterCreator.Location = new System.Drawing.Point(48, 22);
            this.lblStarWarsCharacterCreator.Name = "lblStarWarsCharacterCreator";
            this.lblStarWarsCharacterCreator.Size = new System.Drawing.Size(953, 77);
            this.lblStarWarsCharacterCreator.TabIndex = 42;
            this.lblStarWarsCharacterCreator.Text = "Star Wars Character Creator\r\n";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lblStarWarsCharacterCreator);
            this.Controls.Add(this.grpBoxSkills);
            this.Controls.Add(this.grpBoxSkillPoints);
            this.Controls.Add(this.btnPictureNext);
            this.Controls.Add(this.btnPicturePrev);
            this.Controls.Add(this.picBoxPortraits);
            this.Controls.Add(this.btnOpenFile);
            this.Controls.Add(this.btnSaveFile);
            this.Controls.Add(this.grpBoxGender);
            this.Controls.Add(this.txtBoxName);
            this.Controls.Add(this.lblName);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Text = "Star Wars Character Creator";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.grpBoxGender.ResumeLayout(false);
            this.grpBoxGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPortraits)).EndInit();
            this.grpBoxSkillPoints.ResumeLayout(false);
            this.grpBoxSkillPoints.PerformLayout();
            this.grpBoxSkills.ResumeLayout(false);
            this.grpBoxSkills.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtBoxName;
        private System.Windows.Forms.GroupBox grpBoxGender;
        private System.Windows.Forms.RadioButton rdoBtnFemale;
        private System.Windows.Forms.RadioButton rdoBtnMale;
        private System.Windows.Forms.Button btnStrengthDown;
        private System.Windows.Forms.Button btnStrengthUp;
        private System.Windows.Forms.Button btnAgilityDown;
        private System.Windows.Forms.Button btnAgilityUp;
        private System.Windows.Forms.Button btnAttackDown;
        private System.Windows.Forms.Button btnAttackUp;
        private System.Windows.Forms.Label lblCharacterPoints;
        private System.Windows.Forms.Label lblStrength;
        private System.Windows.Forms.Label lblAgility;
        private System.Windows.Forms.Label lblAttack;
        private System.Windows.Forms.Button btnSaveFile;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.SaveFileDialog sfdSave;
        private System.Windows.Forms.OpenFileDialog ofdOpen;
        private System.Windows.Forms.PictureBox picBoxPortraits;
        private System.Windows.Forms.Button btnPicturePrev;
        private System.Windows.Forms.Button btnPictureNext;
		private System.Windows.Forms.Button btnCharismaDown;
		private System.Windows.Forms.Button btnStaminaDown;
		private System.Windows.Forms.Button btnForceDown;
		private System.Windows.Forms.Button btnDefenceDown;
		private System.Windows.Forms.Button btnVitalityDown;
		private System.Windows.Forms.Label lblForce;
		private System.Windows.Forms.Label lblStamina;
		private System.Windows.Forms.Label lblCharisma;
		private System.Windows.Forms.Label lblVitality;
		private System.Windows.Forms.Label lblDefence;
		private System.Windows.Forms.Button btnVitalityUp;
		private System.Windows.Forms.Button btnCharismaUp;
		private System.Windows.Forms.Button btnStaminaUp;
		private System.Windows.Forms.Button btnForceUp;
		private System.Windows.Forms.Button btnDefenceUp;
		private System.Windows.Forms.GroupBox grpBoxSkillPoints;
		private System.Windows.Forms.GroupBox grpBoxSkills;
		private System.Windows.Forms.Label lblStarWarsCharacterCreator;
	}
}

